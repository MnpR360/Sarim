using M2MqttUnity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using uPLibrary.Networking.M2Mqtt.Messages;


public class ClientM2 : M2MqttUnityClient
{
    public class TwistData
    {
        public Vector3 linear;
        public Vector3 angular;
    }
    public class Robot
    {
        public int id;
        public string name;
        public float battry;
        public float lat;
        public float lon;
        public float heading;
    }

   

    public MoveTest UGVMove;

    bool goSub = false;
    bool goPub = false;

    Robot robot1 = new Robot();
    public string topicNamePub = "sarim-ae/rover/1";
    public string topicNameSub = "sarim-ae/rover/1/command";
    string msgSend = "Test message";
 
    

    private List<string> eventMessages = new List<string>();

    public void TestPublish(string topic, string msg)
    {   
        client.Publish(topic, System.Text.Encoding.UTF8.GetBytes(msg), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
        Debug.Log("Test message published");
    }
    protected override void OnConnecting()
    {
        base.OnConnecting();
        Debug.Log("Connecting to broker on " + brokerAddress + ":" + brokerPort.ToString() + "...\n");
    }

    public void SetBrokerAddress(string brokerAddress)
    {
        this.brokerAddress = brokerAddress;
    }

    public void SetBrokerPort(string brokerPort)
    {
        int.TryParse(brokerPort, out this.brokerPort);
    }


    protected override void DecodeMessage(string topic, byte[] message)
    {
        string msg = System.Text.Encoding.UTF8.GetString(message);
        Debug.Log("Received in DecodeMessage: " + msg);
        StoreMessage(msg);        
    }

    private void StoreMessage(string eventMsg)
    {
        eventMessages.Add(eventMsg);
    }

    private void ProcessMessage(string msg)
    {
        Debug.Log("Received in ProcessMessage: " + msg);
    }


    private void ConectionPP()
    {
        base.Update(); // call ProcessMqttEvents()

        if (client != null && goSub)
        {
            SubscribeTopics();
            goSub = false;
        }

        if (client != null && goPub)
        {
            TestPublish(topicNamePub, msgSend);
            goPub = false;
        }

        if (eventMessages.Count > 0)
        {
            foreach (string msg in eventMessages)
            {
                ProcessMessage(msg);
            }
            eventMessages.Clear();
        }
    }

    protected override void Update()
    {
        ConectionPP();
        Debug.Log(UGVMove.GetComponent<Transform>().position);
    }

    protected override void SubscribeTopics()
    {
        
            client.Subscribe(new string[] { topicNameSub + "/command" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });
        Debug.Log("Sub to " + topicNameSub);
    }

    protected override void UnsubscribeTopics()
    {
        client.Unsubscribe(new string[] { topicNameSub });
    }

    protected override void OnConnectionFailed(string errorMessage)
    {
        Debug.Log("CONNECTION FAILED! " + errorMessage);
    }


    protected override void Start()
    {

        robot1.id = 1;
        robot1.name = "Dawood";
        robot1.battry = 1;
        robot1.lat = 0;
        robot1.lon = 0;
        robot1.heading = 0;

        string json = JsonUtility.ToJson(robot1);
        msgSend = json;

        base.Start();



        // connect to the mqtt
        base.Connect();



        // subscribe to topic / listen to incoming msgs 
        goSub = true;



        // publish to topic
        goPub = true;
    }




}


