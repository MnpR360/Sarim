using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using uPLibrary.Networking.M2Mqtt;

public class UGVMQTT : MonoBehaviour
{
    public ClientM2 clientClass;

    //these values are taken by M2MqttUnityClient class
    [Header("MQTT broker configuration")]
    public string brokerAddress = "broker.hivemq.com";
    public int brokerPort = 1883;
    public bool isEncrypted = true;
    //--------------------------------------------------

    public class Robot
    {
        public int ID;
        public string Name;
        public string Status;
        public float Battery;
        public float Latitude;
        public float Longitude;
        public float Heading;
    }

    Robot robot1 = new Robot();
    public string topicNamePub = "sarim-ae/rover/robot-status";
    public string topicNameSub = "sarim-ae/rover/1";
    string msgSend = "Test message new UGVMQTT";

    float timeToSend;
    float waitTime = 1;
    // Start is called before the first frame update
    void Start()
    {
        timeToSend = Time.time + waitTime;

        robot1.ID = 3;
        robot1.Status = "Active";
        robot1.Name = "Dawood";
        robot1.Battery = 1;

        clientClass.ConnectToServer();

        StartCoroutine((SubToTopic()));


    }

    private IEnumerator SubToTopic()
    {
        yield return new WaitForSeconds(0.1f);
        clientClass.SubscribeTopics(topicNameSub);
    }




    // Update is called once per frame
    void Update()
    {

        if (Time.time > timeToSend)
        {
            timeToSend = Time.time + waitTime;

            CoordsConverter converter = GetComponent<CoordsConverter>();
            Vector2 xyCoordinates = new Vector2(transform.position.x, transform.position.z); // Replace with your own x and y coordinates
            Vector2 lonLat = converter.ConvertXZToLonLat(xyCoordinates);

            robot1.Latitude = lonLat.x;
            robot1.Longitude = lonLat.y;
            robot1.Heading = transform.eulerAngles.y;


            string json = JsonUtility.ToJson(robot1);
            msgSend = json;

            clientClass.PublishMSG(topicNamePub, msgSend);
        }
    }
}
